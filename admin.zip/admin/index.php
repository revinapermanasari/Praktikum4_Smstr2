<?php 
include_once 'top.php';
include_once 'menu.php';
?>
<div>
    <div class="container-fluid px-4 pt-4">
        <h1>Selamat Datang di halaman Admin</h1>
    </div>
</div>
<?php 
include_once 'bottom.php';
?>