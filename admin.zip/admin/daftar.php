<?php 
include_once 'top.php';
include_once 'menu.php';
?>
<div>
    <div class="container-fluid px-4 pt-4">
        <h1>Silahkan Isi form Pendaftaran</h1>
        <?php include_once 'form_daftar.php' ?>
    </div>
</div>
<?php 
include_once 'bottom.php';
?>