<?php 
$ar_menu = [
    'Home' => 'index.php',
    'Daftar' => 'daftar.php',
    'Array Buah' => 'array_buah.php'
];
?>